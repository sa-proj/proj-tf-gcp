PROJECT_ID = "qwiklabs-gcp-01-cff77cda449c"
PUBSUB_TOPIC = "topic_mql_metric_export"
BIGQUERY_DATASET = "sample"
BIGQUERY_TABLE = "spanner_mql_metrics"


MQL_QUERYS = {
"spanner/instance/cpu/smoothed_utilization":
"""
fetch spanner_instance
| metric 'spanner.googleapis.com/instance/cpu/smoothed_utilization'
| filter
    resource.project_id == 'qwiklabs-gcp-01-cff77cda449c'
    && (resource.instance_id == 'spanner-1')
| group_by 1m,
    [value_smoothed_utilization_mean: mean(value.smoothed_utilization)]
| every 5m | within 1h
""",

"spanner/instance/cpu/utilization_by_priority":
"""
fetch spanner_instance
| metric 'spanner.googleapis.com/instance/cpu/utilization_by_priority'
| filter
    resource.project_id == 'qwiklabs-gcp-01-cff77cda449c'
    && (resource.instance_id == 'spanner-1') && (metric.priority == 'high')
| group_by 1m,
    [value_utilization_by_priority_mean: mean(value.utilization_by_priority)]
| every 1m
| group_by [],
    [value_utilization_by_priority_mean_aggregate:
       aggregate(value_utilization_by_priority_mean)]
""",

"spanner/instance/storage/used_bytes":
"""
fetch spanner_instance
| metric 'spanner.googleapis.com/instance/storage/used_bytes'
| filter
    resource.project_id == 'qwiklabs-gcp-01-cff77cda449c'
    && (resource.instance_id == 'spanner-1')
| group_by 10m,
    [value_used_bytes_max: max(value.used_bytes)]
| every 5m | within 1h
""",

"spanner/instance/error_count":
"""
fetch spanner_instance
| metric 'spanner.googleapis.com/api/api_request_count'
| filter
    resource.project_id == 'qwiklabs-gcp-01-cff77cda449c'
    && (resource.instance_id == 'spanner-1') && (metric.status != 'OK')
| align rate(1m)
| every 1m
| group_by [],
    [value_api_request_count_aggregate: aggregate(value.api_request_count)]
"""
}

BASE_URL = "https://monitoring.googleapis.com/v3/projects"
QUERY_URL = f"{BASE_URL}/{PROJECT_ID}/timeSeries:query"


BQ_VALUE_MAP = {
    "INT64": "int64_value",
    "BOOL": "boolean_value",
    "DOUBLE": "double_value",
    "STRING": "string_value",
    "DISTRIBUTION": "distribution_value"
}

API_VALUE_MAP = {
    "INT64": "int64Value",
    "BOOL": "booleanValue",
    "DOUBLE": "doubleValue",
    "STRING": "stringValue",
    "DISTRIBUTION": "distributionValue"
}
